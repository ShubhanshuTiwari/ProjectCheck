package com.capstore.service;

import java.util.List;

import com.capstore.bean.Product;

public interface IProductService {

	public List<Product> getProduct();
	
}
