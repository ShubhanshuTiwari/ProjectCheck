package com.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.bean.Product;
import com.capstore.repo.IProductRepo;

@Service
public class ProductService implements IProductService{

	@Autowired
	IProductRepo productRepo;

	@Override
	public List<Product> getProduct() {
		// TODO Auto-generated method stub
		return productRepo.getProduct();
	}

	
}
