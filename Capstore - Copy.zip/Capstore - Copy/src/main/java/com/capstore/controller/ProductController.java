
package com.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.capstore.bean.Product;
import com.capstore.service.IProductService;

@Controller
public class ProductController {

	@Autowired
	IProductService productService;
	
	@RequestMapping(method = RequestMethod.GET, value = "/")
	public String index(ModelMap map) {
		
	List<Product> list=productService.getProduct();
	map.addAttribute("product",list);
	System.out.println(list);
		return "index";
	}
	
	@RequestMapping("/about")
	String loadAbout(ModelMap modal) {
		return "about";
	}
	
}
