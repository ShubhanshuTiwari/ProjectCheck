package com.capstore.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capstore.bean.Product;


@Repository
@Transactional
public class ProductRepo implements IProductRepo {

	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Override
	public List<Product> getProduct() {
		// TODO Auto-generated method stub
		
		TypedQuery<Product> query=entityManager.createQuery("select prod from Product prod ", Product.class);  // for retrieving the data from table
		
		List<Product> list= query.getResultList();
	return list;
	}

}
